InitWindow(800, 600, "Hello World")

while not WindowShouldClose() do
    BeginDrawing()
    ClearBackground(0, 0, 0)

    EndDrawing()
end